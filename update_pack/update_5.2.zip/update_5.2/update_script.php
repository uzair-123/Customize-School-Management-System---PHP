<?php
	$CI = get_instance();
	$CI->load->database();
	$CI->load->dbforge();

  // creating group_message table
  $group_message_fields = array(
    'group_message_id' => array(
            'type' => 'INT',
            'primary' => TRUE,
            'auto_increment' => TRUE,
            'constraint' => '10'
    ),
    'group_message_thread_code' => array(
            'type' => 'LONGTEXT',
            'null'  => TRUE
    ),
    'sender' => array(
            'type' => 'LONGTEXT',
            'null'  => TRUE
    ),
    'message' => array(
            'type' => 'LONGTEXT',
            'null' => TRUE
    ),
    'timestamp' => array(
            'type' => 'LONGTEXT',
            'null' => TRUE
    ),
    'read_status' => array(
            'type' => 'INT',
            'constraint' => '10',
            'null' => TRUE
    ),
    'attached_file_name' => array(
            'type' => 'LONGTEXT',
            'null' => TRUE
    ),
  );

$CI->dbforge->add_key('group_message_id', TRUE); // defining group_message_id as primary key
$CI->dbforge->add_field($group_message_fields);
$CI->dbforge->create_table('group_message'); // table has to be added after adding the columns


// creating group_message_thread table
$group_message_thread_fields = array(
  'group_message_thread_id' => array(
          'type' => 'INT',
          'primary' => TRUE,
          'auto_increment' => TRUE,
          'constraint' => '10'
  ),
  'group_message_thread_code' => array(
          'type' => 'LONGTEXT',
          'null'  => TRUE
  ),
  'members' => array(
          'type' => 'LONGTEXT',
          'null'  => TRUE
  ),
  'group_name' => array(
          'type' => 'LONGTEXT',
          'null' => TRUE
  ),
  'last_message_timestamp' => array(
          'type' => 'LONGTEXT',
          'null' => TRUE
  ),
  'created_timestamp' => array(
          'type' => 'LONGTEXT',
          'null' => TRUE
  ),
);

$CI->dbforge->add_key('group_message_thread_id', TRUE); // defining group_message_id as primary key
$CI->dbforge->add_field($group_message_thread_fields);
$CI->dbforge->create_table('group_message_thread'); // table has to be added after adding the columns

//insert paypal row
$paypal_updater = array(
	'type' => 'paypal',
	'description' => '[{"active":"1","mode":"sandbox","sandbox_client_id":"AZDxjDScFpQtjWTOUtWKbyN_bDt4OgqaF4eYXlewfBP4-8aqX3PiV8e1GWU6liB2CUXlkA59kJXE7M6R","production_client_id":"SomeId"}]'
);
$CI->db->insert('settings',$paypal_updater);

//insert Stripe row
$stripe_updater = array(
	'type' => 'stripe_keys',
	'description' => '[{"active":"1","testmode":"on","public_key":"pk_test_c6VvBEbwHFdulFZ62q1IQrar","secret_key":"sk_test_9IMkiM6Ykxr1LCe2dJ3PgaxS","public_live_key":"pk_live_xxxxxxxxxxxxxxxxxxxxxxxx","secret_live_key":"sk_live_xxxxxxxxxxxxxxxxxxxxxxxx"}]'
);
$CI->db->insert('settings',$stripe_updater);

?>
